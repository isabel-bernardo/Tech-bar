export class PlayerOne {
    name: string;
    weapon: boolean;
    flashlight: boolean;
    map: boolean;
}