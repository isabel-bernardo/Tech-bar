export class Room {
    id: number;
    description: string;
}